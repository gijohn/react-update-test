const { createWebpackAliases } = require('./webpack.helpers');

/**
 * Export Webpack Aliases
 *
 * Tip: Some text editors will show the errors or invalid intellisense reports
 * based on these webpack aliases, make sure to update `tsconfig.json` file also
 * to match the `paths` we using in here for aliases in project.
 */
module.exports = createWebpackAliases({
  '@assets': 'assets',
  '@components': 'src/components',
  '@pages': 'src/pages',
  '@services': 'src/service',
  '@actions': 'src/action',
  '@types': 'src/type',
  '@utils': 'src/utils',
  '@test': 'test'
});

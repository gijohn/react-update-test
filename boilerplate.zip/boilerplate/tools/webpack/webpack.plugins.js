const webpack = require('webpack');
const { inDev } = require('./webpack.helpers');
const ForkTsCheckerWebpackPlugin = require('fork-ts-checker-webpack-plugin');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const ReactRefreshWebpackPlugin = require('@pmmmwh/react-refresh-webpack-plugin');
const path = require("path");
const Dotenv = require("dotenv-webpack");
const dotenv = require("dotenv");

const ENV = process.env.ENV || "development";
const rootPath = path.join(path.resolve(__dirname, "../.."), "config", ENV, ".env");

dotenv.config({ path: rootPath });

module.exports = [
  new ForkTsCheckerWebpackPlugin(),
  inDev() && new webpack.HotModuleReplacementPlugin(),
  inDev() && new ReactRefreshWebpackPlugin(),
  new Dotenv({
    path: rootPath,
  }),
  new webpack.DefinePlugin({
    "process.env.Env": JSON.stringify(process.env)
  }),
  new HtmlWebpackPlugin({
    template: 'public/index.html',
    favicon: 'assets/images/favicon.png',
    inject: true,
  }),
  new MiniCssExtractPlugin({
    filename: '[name].[chunkhash].css',
    chunkFilename: '[name].[chunkhash].chunk.css',
  }),
].filter(Boolean);

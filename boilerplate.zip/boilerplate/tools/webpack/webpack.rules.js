module.exports = [
  {
    // Typescript loader
    test: /\.tsx?$/,
    exclude: /(node_modules\/(?!(bitbucket|ky|@socure)\/)|\.webpack)/,
    use: {
      loader: 'ts-loader',
      options: {
        transpileOnly: true,
      },
    },
  },
  {
    test: /\.(scss|css)$/,
    use: [
      {
        loader: "style-loader",
      },
      {
        loader: "css-loader",
        options: { sourceMap: true, importLoaders: 1 },
      },
      { loader: "sass-loader", options: { sourceMap: true } },
    ],
  },
  {
    test: /\.svg$/i,
        issuer: /\.[jt]sx?$/,
        use: ['@svgr/webpack', 'url-loader'],
  },
  {
    test: /node_modules\/.*\.svg$/,
    type: 'asset',
    generator: {
      filename: 'assets/[hash][ext][query]',
    },
  },
  {
    // Assets loader
    // More information here https://webpack.js.org/guides/asset-modules/
    test: /\.(gif|jpe?g|tiff|png|webp|bmp|eot|ttf|woff|woff2)$/i,
    type: 'asset',
    generator: {
      filename: 'assets/[hash][ext][query]',
    },
  },
  {
    test: /\.mp4$/,
    use: [
      {
        loader: 'url-loader',
        options: {
          limit: 8192, // limit for converting small files to base64
          name: '[name].[ext]',
          outputPath: 'videos/'
        }
      }
    ]
  }
];

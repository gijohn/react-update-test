window.process.env.LANDING_PAGE = 'https://dashboard.resultlane.com/';

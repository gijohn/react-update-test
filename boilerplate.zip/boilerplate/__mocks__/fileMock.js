/* eslint-env node */
module.exports = 'test-file-stub';

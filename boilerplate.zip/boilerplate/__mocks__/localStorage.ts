interface LocalStorage {
    [key: string]: string
}
let _localStorage:LocalStorage = {};

// eslint-disable-next-line @typescript-eslint/no-explicit-any
(window as any).localStorage = (window as any).sessionStorage = {
  setItem(key: string, value: string) {
    Object.assign(_localStorage, { [key]: value });
  },
  getItem(key: string): string | null {
      return Object.prototype.hasOwnProperty.call(_localStorage, key) ? _localStorage[key] : null;
  },
  clear() {
    _localStorage = {};
  },
};

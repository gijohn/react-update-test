import type { UserAuth } from '@types';
import type { AxiosResponse } from 'axios';
import axios from '../common/CustomAxios';

export const retrieveSession = async (): Promise<UserAuth> => {
    return axios
        .get('/transaction/LoggedInUser')
        .then((response: AxiosResponse) => {
            console.log(response)
            const responseData = response.data.data as UserAuth;
            return responseData;
        });
}   
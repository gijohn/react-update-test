
import { Map as ImmutableMap } from 'immutable';
import { ActionType, GlobalActions} from '../action/global';

export type GlobalState = ImmutableMap<string, unknown> | null;

export default (state: GlobalState = null, action: GlobalActions): GlobalState => {
    if (!state) {
        return ImmutableMap({
            loading: false,
        })
    }

    switch (action.type) {
        case ActionType.setLoader:
            return state.set('loading', action.payload.loading);
        default:
            break;
    }
    return state;
};

export const getLoader = (state: GlobalState): boolean => state?.get('loading') as boolean;
import type { Account, AccountIdName, ApiResponse, Transaction, User, iReasonCode, MyInterestItemId, MyFocusItemId } from '@types';
import { Map as ImmutableMap } from 'immutable';
import { ActionType, UIAction } from '../action/ui';

export type UIState = ImmutableMap<string, unknown> | null;

export default (state: UIState = null, action: UIAction): UIState => {
    if (!state) {
        return ImmutableMap({
            sessionStatus: 'loading'
        })
    }

    switch (action.type) {
        case ActionType.setUser:
            return state.set('user', action.payload.user);
        case ActionType.setAccount:
            return state.set('account', action.payload.account);
        case ActionType.setStatusActive:
            return state.set('sessionStatus', 'active');
        case ActionType.setStatusExpire:
            return state.set('sessionStatus', 'expired');
        case ActionType.resetActiveSession:
            return state.set('sessionStatus', 'loading');
        default:
            break;
    }
    return state;
};
export type SessionStateType = 'loading' | 'active' | 'expired';

export const getSessionStatus = (state: UIState): SessionStateType =>
    state?.get('sessionStatus') as SessionStateType;
export const getUser = (state: UIState): User =>
    state?.get('user') as User;
export const getAccount = (state: UIState): Account =>
    state?.get('account') as Account;
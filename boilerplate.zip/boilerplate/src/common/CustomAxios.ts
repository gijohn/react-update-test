import axios from "axios";
import { AxiosError, AxiosRequestConfig, AxiosRequestHeaders } from "axios"
import type { Store } from 'redux';
import { uiActions } from "../action/ui";

interface AdaptAxiosRequestConfig extends AxiosRequestConfig {
  headers: AxiosRequestHeaders
}

const baseURL = process.env.API_URL;

const instance = axios.create({
  baseURL,
  withCredentials: true,
  // maxRedirects: 0
});

const setupAxios = (store: Store): void => {
  // Add a request interceptor
  instance.interceptors.request.use(
    (config: AdaptAxiosRequestConfig) => {
      return config;
    },
    (error) => {
      return Promise.reject(error);
    },
  );

  // Add a response interceptor
  instance.interceptors.response.use(
    (response) => {
      console.log(response); //eslint-disable-line no-console
      return response;
    },
    (error: AxiosError) => {
      console.log("Error handled in interceptor"); //eslint-disable-line no-console
      console.log(error); //eslint-disable-line no-console
      const errorResponse = error.response;
      if (errorResponse) {
        const { status = 0 } = errorResponse;
        if ([301, 302].includes(status)) {
          const redirecturl = errorResponse.headers.location;
          redirecturl && window.location.replace(redirecturl);
        } else if (status === 401) {
          store.dispatch(uiActions.setStatusExpire());
          return Promise.reject(error);
        }
      } else if (error.request && error.code === AxiosError.ERR_NETWORK) {
        //Since Axios does not provide response object for redirection, we have to handle redirection by ourself, if no response object available.
        process.env.LANDING_URL && window.location.replace(process.env.LANDING_URL);
      }
      return Promise.reject(error);
    }
  );
}


export default instance;
export { setupAxios };

import { retrieveSession } from '@services/session';
import type { Account, User } from '@types';
import type { Dispatch } from 'redux';
import type { ThunkAction } from 'redux-thunk';
import type { ActionType as Action } from 'typesafe-actions';
import { action } from 'typesafe-actions';
import { RootState } from '../store';

export enum ActionType {
	setUser = 'setUser',
	setAccount = 'setAccount',
	setStatusActive = 'setStatusActive',
	setStatusExpire = 'setStatusExpire',
	resetActiveSession = 'resetActiveSession'
}

const setUser = (user: User) => action(ActionType.setUser, { user });
const setAccount = (account: Account) => action(ActionType.setAccount, { account });
const setStatusActive = () => action(ActionType.setStatusActive);
const setStatusExpire = () => action(ActionType.setStatusExpire);
const resetActiveSession = () => action(ActionType.resetActiveSession);
const retrieveSessionUser = (): ThunkAction<void, RootState, unknown, Action<string>> => async (
    dispatch: Dispatch
  ) => {
      try {
          const loginResponse = await retrieveSession();
          dispatch(setUser(loginResponse.user))
          dispatch(setAccount(loginResponse.account))
          dispatch(setStatusActive())
      } catch (ex) {
          dispatch(setStatusExpire());
          console.log("login validation failed", ex);
    }
  };

export const uiActions = {
	setUser,
	setAccount,
	setStatusActive,
	setStatusExpire,
	resetActiveSession,
  retrieveSessionUser
};

export type UIAction = Action<typeof uiActions>;

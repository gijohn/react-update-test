import {action, type ActionType as Action } from "typesafe-actions";

export enum ActionType {
    setLoader = 'setLoader',
}

const setLoader = (loading: boolean) => action(ActionType.setLoader, { loading });

export const globalActions = {
    setLoader
}

export type GlobalActions = Action<typeof globalActions>;

import type { ThunkDispatch } from '@reduxjs/toolkit';
import { configureStore } from '@reduxjs/toolkit';
import type { Action } from 'typesafe-actions';
import { setupAxios } from '../common/CustomAxios';
import UIReducer, { UIState } from '../reducer/UI';
import GlobalReducer, { GlobalState } from '../reducer/Global';

export type RootState = {
    UI: UIState;
    Global: GlobalState;
};

const store = configureStore({
    reducer: {
        UI: UIReducer,
        Global: GlobalReducer
    }
});

// Allows for calling Thunk actions without specifying the ThunkDispatch type on every useDispatch()
export type AppDispatch = typeof store.dispatch & ThunkDispatch<RootState, void, Action<string>>;

setupAxios(store);
export default store;

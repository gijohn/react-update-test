import {use} from 'i18next';
import LanguageDetector from 'i18next-browser-languagedetector';
import { initReactI18next } from 'react-i18next';
import LocaleEnglish from "@assets/locales/en.json";
import LocaleFrench from "@assets/locales/fr.json";

const Languages = ["en", "fr"];

const i18n = use(LanguageDetector)
.use(initReactI18next)
.init({
    lng: navigator.language,
    fallbackLng: "en",
    detection: {
        order: ["queryString", 'cookie'],
        caches: ['cookie']
    },
    supportedLngs: Languages,
    ns: ['translations'],
    defaultNS: 'translations',
    debug: false,
    interpolation: {
        escapeValue: false
    },
    resources: { 
        en: {
            translations: LocaleEnglish
        },
        fr: {
            translations: LocaleFrench
        }
    },
}, (err, t) => {
    // eslint-disable-next-line no-console
    if (err) {return console.log(`something went wrong loading${ err}`)}
    t('key'); // -> same as i18next.t
  });

export default i18n;
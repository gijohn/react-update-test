export interface Account {
  id: number;
  name: string;
  publicId: string;
  permission: string[];
  isActive: boolean;
}

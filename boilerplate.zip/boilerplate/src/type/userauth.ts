import type { User } from './user';
import type { Account } from './account';

export interface UserAuth {
  user: User;
  account: Account;
}

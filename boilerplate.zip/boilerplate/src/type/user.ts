export interface User {
    id: number;
    firstName: string;
    lastName: string;
    email: string;
    isLocked: boolean;
    isAdmin: boolean;
    passwordUpdatedAt?: string;
    passwordExpireAt?: string;
  }
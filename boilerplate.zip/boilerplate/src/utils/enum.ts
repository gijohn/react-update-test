export enum TransactionAPI {
    OLD_API = "/api/2.5/",
    NEW_API = "/api/3.0/"
}

export enum ErrorPageTypes {
    DOCV = 'docv',
}
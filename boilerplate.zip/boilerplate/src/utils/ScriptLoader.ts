export default (scriptSrc: string,srcAsync: boolean=false,onLoadCallback:()=>void=()=>{}): Promise<void> => {
    return new Promise((resolve, reject) => {
      try {
        const oHead = document.getElementsByTagName('head')[0];
        let scripts = oHead.getElementsByTagName('script');
        for (let i = 0; i < scripts.length; i++) {
          if (scripts[i].src === scriptSrc) {
            reject();
            return;
          }  //eslint-disable-line no-continue
        }
        const oScript = document.createElement('script');
        oScript.type = 'text/javascript';
        oScript.src = scriptSrc;
        oScript.async = srcAsync;
        oScript.onload = () => {
          onLoadCallback();
          resolve();
        };
        oScript.onerror = () => {
          reject();
        };
        oScript.onabort = () => {
          reject();
        };
        oScript.oncancel = () => {
          reject();
        };
        oHead.appendChild(oScript);
      } catch (e) {
        console.log('Problem in adding script', e); //eslint-disable-line no-console
        reject();
      }
    });
  };
  
  
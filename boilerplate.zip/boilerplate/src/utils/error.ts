export class AccessDeniedError extends Error {}

export class TimeOutError extends Error {}

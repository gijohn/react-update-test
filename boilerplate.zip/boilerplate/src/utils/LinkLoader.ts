export default (resourceSrc: string, rel: 'stylesheet'): Promise<void> => {
    return new Promise((resolve, reject) => {
      try {
        const oHead = document.getElementsByTagName('head')[0];
        const oScript = document.createElement('link');
  
        oScript.rel = rel;
        oScript.href = resourceSrc;
  
        oScript.onload = () => {
          resolve();
        };
        oScript.onerror = () => {
          reject();
        };
        oScript.onabort = () => {
          reject();
        };
        oScript.oncancel = () => {
          reject();
        };
        oHead.appendChild(oScript);
      } catch (e) {
        console.log("Problem in adding script", e); //eslint-disable-line no-console
        reject();
      }
    });
  }
  
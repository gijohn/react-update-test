import React, { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { Provider } from 'react-redux';
import { HashRouter } from 'react-router-dom';
import App from './App';
import store from './store';


const Application: React.ReactNode = <StrictMode>
    <Pendo />
    <Provider store={store}>
        <HashRouter>
            <App />
        </HashRouter>
    </Provider>
</StrictMode>;

createRoot(document.getElementById('app')).render(Application);
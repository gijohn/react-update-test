const { jsWithTs: tsjPreset } = require('ts-jest/presets');
const { pathsToModuleNameMapper } = require('ts-jest');
const { compilerOptions } = require('./tsconfig');

module.exports = {
  roots: ['<rootDir>/src'],
  preset: 'ts-jest',
  testEnvironment: 'jsdom',
  collectCoverage: true,
  moduleFileExtensions: ['js', 'jsx', 'ts', 'tsx', 'json'],
  moduleNameMapper: {
    '^src(.*)$': '<rootDir>/src$1',
    '\\.(jpg|jpeg|png|gif|eot|otf|webp|svg|ttf|woff|woff2|mp4|webm|wav|mp3|m4a|aac|oga)$':
      '<rootDir>/__mocks__/fileMock.js',
    '\\.(css|less|scss)$': '<rootDir>/__mocks__/styleMock.js',
    // '^dnd-core$': 'dnd-core/dist/cjs',
    // '^react-dnd$': 'react-dnd/dist/cjs',
    // '^react-dnd-html5-backend$': 'react-dnd-html5-backend/dist/cjs',
    ...pathsToModuleNameMapper(compilerOptions.paths, { prefix: '<rootDir>/' }),
  },
  moduleDirectories: ['node_modules', 'src'],
  transform: {
    ...tsjPreset.transform,
  },
  transformIgnorePatterns: [
    '<rootDir>/node_modules/(?!(lodash-es|@novnc|@spice-project)/.*)',
  ],
  testRegex: '/__tests__/.*\\.spec\\.(ts|tsx|js|jsx)$',
  testEnvironmentOptions: {
    url: 'http://localhost'
  },
  setupFiles: [
    './__mocks__/localStorage.ts',
    './__mocks__/matchMedia.js',
    './__mocks__/mutationObserver.js',
    './__mocks__/processMock.js',
    './before-tests.ts',
  ],
  coverageThreshold: {
    global: {
      branches: 70,
      functions: 81,
      lines: 93,
      statements: 93,
    },
  },
  coveragePathIgnorePatterns: ['.*\\.d\\.ts', '<rootDir>/node_modules/'],
  coverageDirectory: '__coverage__',
  coverageReporters: ['json', 'lcov', 'text', 'text-summary'],
  collectCoverageFrom: [
    'src/**/*.{js,jsx,tsx}', 
    '!src/components/**/*'
  ],
  setupFilesAfterEnv: ['<rootDir>/jest-setup.ts'],
};
